package TrinaryNode;

public class TrinaryNode {
	int index;
	TrinaryNode leftcp;
	TrinaryNode centercp;
	TrinaryNode rightcp;

	public TrinaryNode(int index) {
		this.index = index;
		this.leftcp = null;
		this.centercp = null; 
		this.rightcp = null;
	}

}