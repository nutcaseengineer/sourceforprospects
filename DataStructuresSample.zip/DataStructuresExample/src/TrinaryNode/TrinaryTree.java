package TrinaryNode;

public class TrinaryTree {
	TrinaryNode root;

	//Construct an empty TrinaryTree at first
	public TrinaryTree() {
		root = null;
	}

	/* Insert node */

	public TrinaryNode insert(int key,TrinaryNode node) {
		if (node == null) {
			node = new TrinaryNode(key);
		} else if (key < node.index) {
			node.leftcp = insert(key, node.leftcp);
		} else if (key == node.index) {
			node.centercp = insert(key, node.centercp) ;
		} else {
			node.rightcp = insert(key, node.rightcp);
		}
		return node;
	}

	/* Find the min node */

	public TrinaryNode findMin(TrinaryNode node) {
		if (node != null) {
			while (node.leftcp != null) {
				return findMin(node.leftcp);
			}
		}
		return node;
	}

}

