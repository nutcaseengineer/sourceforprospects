import TrinaryNode.*;
public class TestTree {	
	public static void main(String [ ] args)
	{
		TrinaryTree tt = new TrinaryTree();
		tt.insert(0, new TrinaryNode(0));
		System.out.println("Inserting node 0");
		tt.insert(1, new TrinaryNode(1));
		System.out.println("Inserting node 1");

	}
}
